-- create table section ---------------------------------------------------
-- schema 		: regprc	- Registration Processor (enrolment server or ID issuance server)
-- table 		: registration - Registration Processor 
-- table alias  : reg

-- schemas section -------------------------------------------------------

-- create schema if Registration Processor schema not exists
create schema if not exists regprc
;

-- table section ---------------------------------------------------------
create table regprc.registration (
	id character varying(28) not null,
	reg_type character varying(64) not null,
	ref_reg_id character varying(28),

	status_code character varying(64) not null,
	lang_code character varying(3) not null,
	status_comment character varying(256),

	latest_regtrn_id character varying(64),
	latest_trn_type_code character varying(64),
	latest_trn_status_code character varying(64),
	latest_trn_lang_code character varying(3),
	latest_regtrn_dtimes timestamp,	
	trn_retry_count smallint,

	is_active boolean not null,
	cr_by character varying (32) not null,
	cr_dtimes timestamp not null,
	upd_by  character varying (32),
	upd_dtimes timestamp,
	is_deleted boolean,
	del_dtimes timestamp
)
;

-- keys section -------------------------------------------------
 alter table regprc.registration add constraint pk_reg_id primary key (id)
 ;
-- 

-- indexes section -------------------------------------------------
-- create index idx_reg_<colX> on regprc.registration (colX )
-- ;

-- comments section ------------------------------------------------- 
comment on table regprc.registration is 'Registration Processor table is to store id issuance enrolment id and packet id details'
;

--comment on column regprc.registration.<columnname> is 'comment on a column'
--;
