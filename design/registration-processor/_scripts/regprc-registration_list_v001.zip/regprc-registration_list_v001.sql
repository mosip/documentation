-- create table section ---------------------------------------------------
-- schema 		: regprc			- Registration Processor (enrolment server or ID issuance server)
-- table 		: registration_list - List of registration packets synched from registration client to processor
-- table alias  : regl

-- schemas section -------------------------------------------------------

-- create schema if Registration Processor schema not exists
create schema if not exists regprc
;

-- table section ---------------------------------------------------------
create table regprc.registration_list (
	id character varying(32) not null,
	reg_id character varying(28) not null,
	reg_type character varying(64),
	parent_reg_id character varying(32),
	status_code character varying(64),
	status_comment character varying(256),

	lang_code character varying(3) not null,
	is_active boolean not null,
	cr_by character varying (32) not null,
	cr_dtimes timestamp not null,
	upd_by  character varying (32),
	upd_dtimes timestamp,
	is_deleted boolean,
	del_dtimes timestamp
)
;

-- keys section -------------------------------------------------
 alter table regprc.registration_list add constraint pk_regl_id primary key (id)
 ;
-- 

-- indexes section -------------------------------------------------
-- create index idx_regl_<colX> on regprc.registration_list (colX )
-- ;

-- comments section ------------------------------------------------- 
comment on table regprc.registration_list is 'List of Registration to Process'
;

--comment on column regprc.registration_list.<columnname> is 'comment on a column'
--;
